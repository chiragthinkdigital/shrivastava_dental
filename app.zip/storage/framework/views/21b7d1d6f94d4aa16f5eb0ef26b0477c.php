

<?php $__env->startSection('head'); ?>
<?php echo $__env->make('pages.home.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dialogs'); ?>
<?php echo $__env->make('pages.home.dialogs', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<?php echo $__env->make('pages.home.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<?php echo $__env->make('pages.home.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php echo $__env->make('pages.home.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', [
    'lang' => 'en-IN',
    'bodyAttributes' => 'data-clone-lang="en" data-clone-page="index"',
    'pageClass' => 'page home-page',
    'pageStyle' => ' style="timeline-scope:--tl-section-about, --tl-section-services, --tl-section-team, --tl-section-faq, --tl-section-instagram, --tl-section-contacts;"',
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\shrivastava_dental_clinic\shrivastava\resources\views\pages\home.blade.php ENDPATH**/ ?>