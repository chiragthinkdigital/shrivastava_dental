<!DOCTYPE html><html lang="<?php echo e($lang); ?>" class="lenis">
<head>
<?php echo $__env->yieldContent('head'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/site.css', 'resources/js/app.js']); ?>
</head>
<body <?php echo $bodyAttributes; ?>>
<svg aria-hidden="true" style="position:absolute;width:0;height:0;overflow:hidden"><filter id="gold-logo" color-interpolation-filters="sRGB"><feColorMatrix type="matrix" values="0 0 0 0 0.831373 0 0 0 0 0.686275 0 0 0 0 0.215686 0 0 0 1 0"/></filter></svg>
<?php echo $__env->yieldContent('dialogs'); ?>
<div id="__nuxt"><div class="app"><!--[--><div class="<?php echo e($pageClass); ?>"<?php echo $pageStyle; ?>>
<?php echo $__env->yieldContent('header'); ?>
<?php echo $__env->yieldContent('main'); ?>
<?php echo $__env->yieldContent('footer'); ?>
<?php echo $__env->make('partials.tail', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body></html>
<?php /**PATH D:\shrivastava_dental_clinic\shrivastava\resources\views/layouts/app.blade.php ENDPATH**/ ?>